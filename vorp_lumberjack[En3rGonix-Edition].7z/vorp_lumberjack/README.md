# vorp_lumberjack
lumber script 
![Screenshot_6](https://user-images.githubusercontent.com/101003021/190474610-6833924d-58be-4101-a14a-5493445ee5a0.png)

## 1. Requirements

- [VORP-Core GitHub](https://github.com/VORPCORE/vorp-core-lua)
- [VORP-Core Discord](https://discord.com/invite/xhJRGhQFRr)
- **NEED** [syn_minigame](https://cdn.discordapp.com/attachments/903875147050655744/906890251312721940/syn_minigame.rar)

## 2. insallation
`ensure vorp_lumberjack` in your resources.cfg
`ensure syn_minigame` in your resources.cfg

## 3. features
- chop trees and get items 
- this script uses the tooll with durability "metadata"
- Forbid cutting down trees in cities if you want
- Random messages when minigame fail

## 4. credits
- The creator of the original script and everyone who contributed to it.
- systemNEO and DerHobbs for revision
